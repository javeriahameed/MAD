package com.example.constraint

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btn1:Button=findViewById(R.id.button99)

        btn1.setOnClickListener(View.OnClickListener {
            val num:Int = 1
            show(num)

        })
        val btn2:Button=findViewById(R.id.button9)
        btn2.setOnClickListener(View.OnClickListener {
            val num:Int = 2
            show(num)
        })
        val btn3:Button=findViewById(R.id.button7)
        btn3.setOnClickListener(View.OnClickListener {
            val num:Int = 3
            show(num)

        })
        val btn4:Button=findViewById(R.id.button55)
        btn4.setOnClickListener(View.OnClickListener {
            val num:Int = 4
            show(num)
        })
        val btn5:Button=findViewById(R.id.button5)
        btn5.setOnClickListener(View.OnClickListener {
            val num:Int = 5
            show(num)

        })
        val btn6:Button=findViewById(R.id.button6)
        btn6.setOnClickListener(View.OnClickListener {
            val num:Int = 6
            show(num)
        })
        val btn7:Button=findViewById(R.id.button77)
        btn7.setOnClickListener(View.OnClickListener {
            val num:Int = 7
            show(num)

        })
        val btn8:Button=findViewById(R.id.button8)
        btn8.setOnClickListener(View.OnClickListener {
            val num:Int = 8
            show(num)
        })
        val btn9:Button=findViewById(R.id.button2)
        btn9.setOnClickListener(View.OnClickListener {
            val num:Int = 9
            show(num)
        })
        val btn10:Button=findViewById(R.id.button10)
        btn10.setOnClickListener(View.OnClickListener {
            val operator:String="/"
            calculator(operator)
        })
        val btn11:Button=findViewById(R.id.button11)
        btn11.setOnClickListener(View.OnClickListener {
            val operator:String="*"
            calculator(operator)
        })
        val btn12:Button=findViewById(R.id.button12)
        btn12.setOnClickListener(View.OnClickListener {
            val operator:String="+"
            calculator(operator)
        })
        val btn13:Button=findViewById(R.id.button14)
        btn13.setOnClickListener(View.OnClickListener {
            val operator:String="-"
            calculator(operator)
        })
        val btn14:Button=findViewById(R.id.equal)
        btn14.setOnClickListener(View.OnClickListener {
            equal()
        })


    }
    private fun show(n:Int)
    {
        val show:TextView=findViewById(R.id.textView)

        if(show.text.toString() == "0") {
            show.text = n.toString()
        }else {
            show.text=show.text.toString() + n.toString()
        }

    }
    private fun calculator(opt:String)
    {
        val show:TextView=findViewById(R.id.textView)

        if(show.text.toString() == "0") {
            Toast.makeText(this,"Please Enter a value first",Toast.LENGTH_LONG).show()
        }else {
            show.text=show.text.toString() + opt.toString()
        }

    }
    private fun equal()
    {
        val show:TextView=findViewById(R.id.textView)
        val num1: Char =show.text.toString()[0]
        val opt:Char=show.text.toString()[1]
        val num2: Char =show.text.toString()[2]
        if(opt.toString()=="/")
        {
            val divide:Int=num1.toInt()/num2.toInt()
            show.text=divide.toString()
        }
        else if(opt.toString()=="*")
        {
            val xply:Int=num1.toInt()*num2.toInt()
            show.text=xply.toString()
        }
        else if(opt.toString()=="+")
        {
            val plus:Int=num1.toInt()+num2.toInt()
            show.text=plus.toString()
        }
        else if(opt.toString()=="-")
        {
            val minus:Int=num1.toInt()-num2.toInt()
            show.text=minus.toString()
        }

    }


}
