package com.example.myracode

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper
import com.example.myracode.DBContract.myData.Companion.Email
import com.example.myracode.DBContract.myData.Companion.KeyId
import com.example.myracode.DBContract.myData.Companion.Name
import com.example.myracode.DBContract.myData.Companion.RegNo

class DatabaseHandler(context: Context)
    :SQLiteOpenHelper(context,DATABASE_NAME,null,DATABASE_VERSION){
    companion object{
        private  val DATABASE_VERSION =  1
        private  val DATABASE_NAME = "ourData"
    }
    override fun onCreate(db: SQLiteDatabase?) {
        val CREATE_TABLE1 = ("CREATE TABLE " + DBContract.myData.TableName + "("
                + DBContract.myData.KeyId + " INTEGER PRIMARY KEY," + DBContract.myData.Name  + " TEXT,"
                +  DBContract.myData.Email + " TEXT," + DBContract.myData.RegNo + " TEXT" + ")")
        db?.execSQL(CREATE_TABLE1)

    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        db!!.execSQL("DROP TABLE IF EXISTS ${DBContract.myData.TableName}")
        onCreate(db)
    }

    fun addData(data: DataModelClass): Long {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(DBContract.myData.Name, data.name) //  Name
        contentValues.put(DBContract.myData.Email, data.email) //  Email
        contentValues.put(DBContract.myData.RegNo,data.reg) //reg no

        val success = db.insert(DBContract.myData.TableName,null , contentValues)
        return success

    }
    @SuppressLint("Range")
    fun viewdata():ArrayList<DataModelClass>{
        val mylist:ArrayList<DataModelClass> = ArrayList<DataModelClass>()
        val myvalues= "SELECT * FROM ${DBContract.myData.TableName}"
        val db=this.readableDatabase
        // Cursor is used to read the record one by one. Add them to data model class and return a arraylist .
        var cursor: Cursor? = null

        try {
            cursor = db.rawQuery(myvalues, null)

        } catch (e: SQLiteException) {
            db.execSQL(myvalues)
            return ArrayList()
        }

        var id: Int
        var name: String
        var email: String
        var reg: String

        if (cursor.moveToFirst()) {
            do {
                id = cursor.getInt(cursor.getColumnIndex(KeyId))
                name = cursor.getString(cursor.getColumnIndex(Name))
                email = cursor.getString(cursor.getColumnIndex(Email))
                reg = cursor.getString(cursor.getColumnIndex(RegNo))
                val mydata = DataModelClass(id = id, name = name, email = email, reg = reg)
                mylist.add(mydata)

            } while (cursor.moveToNext())
        }
        return mylist
    }
}

