package com.example.myracode

class DataModelClass(val id:Int,val name:String,val email:String,val reg:String) {
}