package com.example.myracode

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ourAdapter(val context: Context): RecyclerView.Adapter<viewholder>() {

    val db: DatabaseHandler = DatabaseHandler(context)
    val title = db.viewdata()
    override fun getItemCount(): Int {
        return title.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): viewholder {
        val linflater = LayoutInflater.from(parent?.context)
        val mylayout = linflater.inflate(R.layout.view,parent,false)
        return viewholder(mylayout)

    }

    override fun onBindViewHolder(holder: viewholder, position: Int) {
        val titlev = title.get(position)
        holder.name.text =titlev.name
        holder.email.text =titlev.email
        holder.reg.text =titlev.reg
    }

}
class  viewholder(val v: View): RecyclerView.ViewHolder(v){
    val name: TextView = v.findViewById(R.id.name)
    val email: TextView = v.findViewById(R.id.email)
    val reg: TextView = v.findViewById(R.id.reg)
}