package com.example.myracode

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
        val pref:SharedPreferences=getSharedPreferences("prefrences", MODE_PRIVATE)
        val input:EditText=findViewById(R.id.input)
        val input2:EditText=findViewById(R.id.input2)
        val input3:EditText=findViewById(R.id.input3)
        input.setText(pref.getString("key",""))
        input2.setText(pref.getString("key2",""))
        input3.setText(pref.getString("key3",""))
        val button:Button=findViewById(R.id.login)
        button.setOnClickListener(){
            val editor:SharedPreferences.Editor=pref.edit()
            editor.putString("key",input.text.toString())
            editor.putString("key2",input2.text.toString())
            editor.putString("key3",input3.text.toString())
            editor.apply()

            val Database: DatabaseHandler = DatabaseHandler(this)
            val status = Database.addData(DataModelClass(0,input.text.toString(),input2.text.toString(),input3.text.toString()))
            if(status>-1)
            {
                Toast.makeText(this,"Data added",Toast.LENGTH_LONG).show()
                val i = Intent(this, MainActivity4::class.java)
                startActivity(i)
            }
            else
            {
                Toast.makeText(this,"not added",Toast.LENGTH_LONG).show()
            }

        }
    }
}