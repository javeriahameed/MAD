package com.example.myracode

import android.provider.BaseColumns

class DBContract {

    class myData:BaseColumns{
       companion object{
           val TableName = "MyTable"
           val KeyId = "_id"
           val Name = "name"
           val Email = "email"
           val RegNo = "reg"
       }
    }

}