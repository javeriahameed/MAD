package com.example.relative_layout

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btn1:Button=findViewById(R.id.one)

        btn1.setOnClickListener(View.OnClickListener {
            val num:Int = 1
            show(num)

        })
        val btn2:Button=findViewById(R.id.two)
        btn2.setOnClickListener(View.OnClickListener {
            val num:Int = 2
            show(num)
        })


    }
    private fun show(n:Int)
    {
        val show:TextView=findViewById(R.id.textview)

        if(show.text.toString() == "0") {
            show.text = n.toString()
        }else {
            show.text=show.text.toString() + n.toString()
        }
        }

    }
